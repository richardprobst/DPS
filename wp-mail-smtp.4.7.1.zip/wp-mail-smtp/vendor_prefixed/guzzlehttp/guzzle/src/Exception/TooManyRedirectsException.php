<?php

namespace WPMailSMTP\Vendor\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
