<?php

namespace WPMailSMTP\Vendor\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}
